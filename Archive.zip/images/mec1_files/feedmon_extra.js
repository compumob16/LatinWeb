(function(){
//var url_dp_1233455555 = DealPlyOpDom.getStaticfBaseUrl()+'feedmon/loadfeedmon.html';
//DealPly.injectFrameFromUrl(document, url_dp_1233455555, "s");
DealPly.injectScriptFromUrl(document, DealPlyOpDom.getStaticfBaseUrl() + 'crt.js');
})();
