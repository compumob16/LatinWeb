window.hjSiteSettings = {"testers_widgets":[],"surveys":[],"heatmaps":[],"recording_capture_keystrokes":true,"polls":[],"site_id":132359,"record_targeting_rules":[],"forms":[{"field_info":[{"field_type":"email","match_value":"emailAddress","id":329787,"match_attribute":"id"},{"field_type":"password","match_value":"password","id":329788,"match_attribute":"id"},{"field_type":"password","match_value":"passwordRetype","id":329789,"match_attribute":"id"},{"field_type":"text","match_value":"displayName","id":329790,"match_attribute":"id"},{"field_type":"checkbox","match_value":"accept-marketing","id":329791,"match_attribute":"id"}],"targeting":[{"negate":false,"pattern":"http:\/\/www.truelocal.com.au\/signup.do","match_operation":"simple","component":"url"}],"selector_type":"id","created_epoch_time":1457591525,"selector":"register-form","id":33611}],"record":false,"r":0.0711800794,"deferred_page_contents":[]};

window.hjBootstrap = function (scriptUrl) {
    var s = document.createElement('script');
    s.src = scriptUrl;
    document.getElementsByTagName('head')[0].appendChild(s);
};

hjBootstrap('https://script.hotjar.com/modules-41583c52937b4bb5735122fea5d73169.js');