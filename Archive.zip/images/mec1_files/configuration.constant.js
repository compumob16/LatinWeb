(function () {
    'use strict';
    angular
        .module('truelocal')
        .constant('env', {
            name: 'prod',
            facebook: {
                appId: '178093711489'
            },
            api: {
              token: 'V0MxbDBlV2VNUw==',
              url: 'https://api.truelocal.com.au/rest/'
            },
            auth: 'api',
            trackingBizWebsiteURL: 'https://api.truelocal.com.au/rest/track/link',
    	      trackingPhoneClickURL: 'https://api.truelocal.com.au/rest/track/phone',
    	      trackingToken: '?passToken=V0MxbDBlV2VNUw==',
            url: 'http://www.truelocal.com.au/',
            socialAuth: {
              tokenUrl: 'https://api.truelocal.com.au/rest/auth/social?passToken=V0MxbDBlV2VNUw==',
              appId: '0677215f57a85027459e38c0f049ad15c05c4b02',
              path: 'http://widget-cdn.rpxnow.com/js/lib/social.for.truelocal.com.au/engage.js',
              securePath: 'https://rpxnow.com/js/lib/social.for.truelocal.com.au/engage.js'
            },
	            urlStructure: '/business/',
	            searchsettings: {
	                businessUrl : '/business'
	            }
        });
})();
